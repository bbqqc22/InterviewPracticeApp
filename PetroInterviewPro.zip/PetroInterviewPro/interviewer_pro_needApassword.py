"""Senior Petrophysicist Interviewer Pro (Streamlit).
Start with the double-click launcher  Start_Interview_App.bat
or run:  streamlit run interviewer_pro_needApassword.py
All data is encrypted in 'interview_vault.enc' (next to this file) and saved automatically.
"""
import csv, hashlib, io, json, os, time
from datetime import datetime

import streamlit as st

import jd_content as jd
import llm_lab as lab
import vault as vl

IDLE_SECONDS = 15 * 60
st.set_page_config(page_title="Petrophysicist Interviewer Pro", page_icon="🛢️", layout="wide")
ss = st.session_state


# ============================================================ security gate
def lock(message=None):
    for k in list(ss.keys()):
        del ss[k]
    if message:
        ss["lock_msg"] = message


def gate():
    """Show the password screen until unlocked. Returns when ss['vault'] is ready."""
    if ss.get("vault") is not None:
        ss["last_active"] = time.time()
        return
    st.title("🛢️ Petrophysicist Interviewer Pro")
    if ss.get("lock_msg"):
        st.info(ss["lock_msg"])
    st.subheader("🔒 Interviewer access")
    if not vl.exists():
        st.info("First time: create a password. It encrypts all candidate data on this computer.")
        st.warning("There is NO password recovery. If you forget it, the data cannot be opened. Write it down somewhere safe.")
        with st.form("create"):
            p1 = st.text_input(f"New password (at least {vl.MIN_PASSWORD} characters)", type="password")
            p2 = st.text_input("Confirm password", type="password")
            ok = st.checkbox("I understand there is no password recovery")
            go = st.form_submit_button("Create encrypted vault", type="primary")
        if go:
            if not ok: st.error("Please tick the box to continue.")
            elif p1 != p2: st.error("Passwords do not match.")
            elif len(p1) < vl.MIN_PASSWORD: st.error(f"Password must be at least {vl.MIN_PASSWORD} characters.")
            else:
                v = vl.Vault.create(p1)
                ss.update(vault=v, data=vl.empty_data(), last_active=time.time())
                st.rerun()
        st.stop()
    wait = vl.lock_seconds_left()
    if wait:
        st.error(f"Too many wrong attempts. Try again in {wait // 60 + 1} minute(s).")
        st.stop()
    with st.form("login"):
        pw = st.text_input("Password", type="password")
        go = st.form_submit_button("Unlock", type="primary")
    if go:
        try:
            v, data = vl.Vault.open(pw)
        except vl.WrongPassword:
            left = vl.register_failure()
            st.error("Wrong password." + (f" {left} attempt(s) left." if left else " Locked for 5 minutes."))
        except (OSError, ValueError, KeyError) as e:
            st.error(f"The vault file could not be read ({e}). A backup copy may exist: interview_vault.bak")
        else:
            vl.register_success()
            ss.update(vault=v, data=data, last_active=time.time())
            st.rerun()
    st.stop()


@st.fragment(run_every="60s")
def idle_watch():
    if ss.get("vault") is not None and time.time() - ss.get("last_active", 0) > IDLE_SECONDS:
        lock("Locked after 15 minutes of inactivity.")
        st.rerun()


def autosave(data):
    h = hashlib.sha256(json.dumps(data, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    if h != ss.get("saved_hash"):
        ss["vault"].save(data)
        ss["saved_hash"], ss["saved_at"] = h, datetime.now().strftime("%H:%M:%S")


# ============================================================ scoring helpers
def candidate_stats(c):
    asked = [q for q, v in c.get("asked", {}).items() if v and q in c.get("ratings", {})]
    scores = [c["ratings"][q] for q in asked]
    rids = {q[:3] for q in asked}
    avg = sum(scores) / len(scores) if scores else None
    return {"asked": len(asked), "avg": avg, "resp": len(rids),
            "guidance": jd.guidance(avg, len(rids)) if avg is not None else "No questions scored yet"}


# ============================================================ tab: interview
def add_candidate():
    name = ss.get("newc", "").strip()
    data = ss["data"]
    if not name:
        ss["cand_msg"] = "Enter a name first."
    elif name.lower() in {n.lower() for n in data["candidates"]}:
        ss["cand_msg"] = "That name already exists - add a middle initial or date."
    else:
        data["candidates"][name] = {"created": datetime.now().strftime("%Y-%m-%d"), "asked": {}, "ratings": {}, "notes": {}, "overall": ""}
        ss["cand_sel"], ss["newc"], ss["cand_msg"] = name, "", ""


def interview_tab(data):
    names = list(data["candidates"])
    c1, c2, c3 = st.columns([3, 3, 1])
    c2.text_input("New candidate", key="newc", placeholder="New candidate name", label_visibility="collapsed")
    c3.button("Add", on_click=add_candidate)
    if ss.get("cand_msg"):
        st.warning(ss["cand_msg"])
    if not names:
        st.info("Add a candidate to begin. Switch each question to 'Asked' only when you actually ask it - unasked questions are never scored.")
        return
    name = c1.selectbox("Candidate", names, key="cand_sel", label_visibility="collapsed")
    c = data["candidates"][name]
    for k, d in (("asked", {}), ("ratings", {}), ("notes", {}), ("overall", "")):
        c.setdefault(k, d)

    top = st.container()
    with st.expander("Scoring rubric (1-5) - applies only to questions you asked"):
        st.table([{"Score": s, "Level": l, "What it looks like": d} for s, l, d in jd.SCALE])

    colL, colR = st.columns(2)
    for i, (rid, title, qs) in enumerate(jd.RESPONSIBILITIES):
        with (colL if i < 6 else colR):
            with st.expander(f"{rid} · {title}"):
                for n, q in enumerate(qs, 1):
                    qid = f"{rid}Q{n}"
                    st.markdown(f"**{q['text']}**")
                    st.caption("Probes: " + "  |  ".join(q["probes"]))
                    st.caption("✅ Listen for: " + "; ".join(q["strong"]))
                    st.caption("🚩 Red flags: " + "; ".join(q["red"]))
                    a, b = st.columns([1, 3])
                    asked = a.toggle("Asked", value=c["asked"].get(qid, False), key=f"as_{name}_{qid}")
                    c["asked"][qid] = asked
                    score = b.slider("Score", 1, 5, value=c["ratings"].get(qid, 3), key=f"sc_{name}_{qid}", disabled=not asked)
                    if asked:
                        c["ratings"][qid] = score
                    c["notes"][qid] = st.text_area("Notes", value=c["notes"].get(qid, ""), key=f"nt_{name}_{qid}", height=68, label_visibility="collapsed", placeholder="Notes / evidence heard")
                    st.divider()
    c["overall"] = st.text_area("Overall impression / recommendation", value=c["overall"], key=f"ov_{name}")

    s = candidate_stats(c)
    with top:
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Questions asked & scored", f"{s['asked']} / 24")
        m2.metric("Responsibilities covered", f"{s['resp']} / 12")
        m3.metric("Average (asked only)", f"{s['avg']:.2f}" if s["avg"] is not None else "-")
        m4.metric("Guidance", s["guidance"])


# ============================================================ tab: candidate questions
def candidate_tab(data):
    st.caption("Questions the candidate is likely to ask at the end. Prepare and save your answers.")
    allq = jd.CANDIDATE_QS + data["custom_candidate_qs"]
    for i, q in enumerate(allq):
        data["prepared_answers"][q] = st.text_area(q, value=data["prepared_answers"].get(q, ""), key=f"cq_{i}", height=80)
    new = st.text_input("Add another question", key="extra_cq")
    if st.button("Add question") and new.strip() and new.strip() not in allq:
        data["custom_candidate_qs"].append(new.strip())
        st.rerun()


# ============================================================ tab: summary
def summary_tab(data):
    if not data["candidates"]:
        st.info("No candidates yet.")
        return
    rows, per = [], []
    for n, c in data["candidates"].items():
        s = candidate_stats(c)
        rows.append({"Candidate": n, "Asked & scored": s["asked"], "Responsibilities": f"{s['resp']}/12",
                     "Average": round(s["avg"], 2) if s["avg"] is not None else None, "Guidance": s["guidance"]})
        r = {"Candidate": n}
        for rid, title, _ in jd.RESPONSIBILITIES:
            v = [c["ratings"][q] for q, a in c.get("asked", {}).items() if a and q.startswith(rid) and q in c.get("ratings", {})]
            r[rid] = round(sum(v) / len(v), 1) if v else None
        per.append(r)
    st.dataframe(rows, width="stretch", hide_index=True)
    st.caption("Score by responsibility (blank = not asked)")
    st.dataframe(per, width="stretch", hide_index=True)
    st.caption("Guidance supports your judgement; it is not a hiring decision. Averages use only questions marked Asked.")

    sel = st.selectbox("Export / manage candidate", list(data["candidates"]), key="sum_sel")
    c = data["candidates"][sel]
    buf = io.StringIO(); w = csv.writer(buf); w.writerow(["question_id", "responsibility", "question", "asked", "score", "notes"])
    for qid, rid, title, q in jd.all_questions():
        w.writerow([qid, title, q["text"], c["asked"].get(qid, False), c["ratings"].get(qid, "") if c["asked"].get(qid) else "", c["notes"].get(qid, "")])
    d1, d2 = st.columns(2)
    d1.download_button("⬇ Scorecard CSV", buf.getvalue(), f"{sel}_scorecard.csv", "text/csv")
    d2.download_button("⬇ Scorecard JSON", json.dumps({sel: c}, indent=2, ensure_ascii=False), f"{sel}_scorecard.json", "application/json")
    with st.popover("🗑 Delete this candidate"):
        st.warning(f"Permanently delete {sel} and all notes?")
        if st.button("Yes, delete", key="del_yes"):
            del data["candidates"][sel]
            for k in [k for k in list(ss.keys()) if isinstance(k, str) and (f"_{sel}_" in k or k == f"ov_{sel}")]:
                del ss[k]
            ss.pop("cand_sel", None)
            st.rerun()


# ============================================================ tab: AI prep lab
def get_client(data):
    try:
        import anthropic
    except ImportError:
        st.error("The 'anthropic' package is missing. Run the launcher again to install it.")
        return None
    key = os.environ.get("ANTHROPIC_API_KEY") or data["settings"].get("api_key", "")
    if not key:
        return None
    return anthropic.Anthropic(api_key=key)


def lab_tab(data):
    st.subheader("Interview-prep JSON (two formats)")
    st.caption("Format A = interview plan (questions, probes, signals, red flags). Format B = scoring rubric (1-5 anchors, weights, guidance).")
    o1, o2 = st.columns(2)
    o1.download_button("⬇ Format A - built-in plan JSON (no AI)", json.dumps(jd.builtin_plan(), indent=2, ensure_ascii=False), "interview_plan.json", "application/json")
    o2.download_button("⬇ Format B - built-in rubric JSON (no AI)", json.dumps(jd.builtin_rubric(), indent=2, ensure_ascii=False), "scoring_rubric.json", "application/json")

    st.divider()
    st.subheader("AI generation, settings test and LLM-as-a-judge")
    env_key = bool(os.environ.get("ANTHROPIC_API_KEY"))
    with st.expander("Anthropic API key" + (" (using ANTHROPIC_API_KEY from this computer)" if env_key else ""), expanded=not (env_key or data["settings"].get("api_key"))):
        k = st.text_input("API key (stored encrypted inside your vault)", value=data["settings"].get("api_key", ""), type="password", key="apikey")
        data["settings"]["api_key"] = k.strip()
        st.caption("Every AI call sends the job description and generated material to Anthropic. Do NOT put candidate names or notes into this tab.")
    client = get_client(data)
    if client is None:
        st.info("Add an API key to enable AI features. The built-in downloads above work without one.")
        return

    st.markdown("**1. Generate once with your chosen settings**")
    with st.form("gen"):
        a, b, c_, d = st.columns(4)
        fmt = a.selectbox("Format", list(lab.FORMATS), format_func=lambda f: lab.FORMATS[f])
        effort = b.selectbox("Reasoning effort", ["low", "medium", "high"], index=1)
        max_tokens = c_.select_slider("Max tokens", [1500, 4000, 8000, 12000, 16000], value=12000)
        temp = d.selectbox("Temperature", ["not sent (default)", 0.0, 0.7, 1.0],
                           help="Current models (Opus/Sonnet 5.5) reject temperature. Pick a value only with a legacy model below.")
        legacy = st.checkbox(f"Use legacy model {lab.LEGACY_TEMP_MODEL} (the only way to test temperature)")
        go = st.form_submit_button("Generate", type="primary")
    if go:
        with st.spinner("Generating..."):
            model = lab.LEGACY_TEMP_MODEL if legacy else lab.GEN_MODEL
            res = lab.generate(client, fmt, model=model, max_tokens=max_tokens, effort=effort, temperature=None if isinstance(temp, str) else temp)
            res["checks"] = lab.checks(fmt, res["parsed"])
        ss["lab_single"] = res
    r = ss.get("lab_single")
    if r:
        if r["ok"]:
            st.success(f"Valid JSON · auto-check {r['checks']['score']} · {r['output_tokens']} output tokens · {r['seconds']}s")
            st.download_button("⬇ Download JSON", json.dumps(r["parsed"], indent=2, ensure_ascii=False), f"{r['format']}_ai.json", "application/json")
            with st.expander("Show JSON / checks"):
                st.json(r["checks"]); st.json(r["parsed"], expanded=False)
        else:
            st.error(r["error"])

    st.markdown("**2. Compare settings and grade with an LLM judge**")
    st.caption(f"Generator `{lab.GEN_MODEL}`, judge `{lab.JUDGE_MODEL}` (different model on purpose). Sweeps reasoning effort and max tokens; "
               "the full run also tries temperature on a legacy model and shows the current model rejecting it.")
    p1, p2, p3 = st.columns(3)
    quick = p1.radio("Size", ["Quick (effort + max tokens)", "Full (adds temperature)"]) .startswith("Quick")
    fmts = p2.multiselect("Formats", list(lab.FORMATS), default=list(lab.FORMATS), format_func=lambda f: lab.FORMATS[f])
    base = p3.checkbox("Include built-in baseline", value=True)
    n_cfg = len(lab.grid(quick)) * len(fmts) + (len(fmts) if base else 0)
    st.caption(f"This makes about {len(lab.grid(quick)) * len(fmts)} generation calls and up to {n_cfg} judge calls, and can take several minutes.")
    if st.button("Run comparison", disabled=not fmts):
        bar = st.progress(0.0, "Starting")
        result = lab.run_experiment(client, formats=tuple(fmts), quick=quick, include_baseline=base,
                                    progress=lambda d_, t_, m_: bar.progress(d_ / t_, f"{d_}/{t_}  {m_}"))
        bar.empty()
        data["lab_runs"] = (data["lab_runs"] + [result])[-5:]
        ss["lab_result"] = result
    res = ss.get("lab_result") or (data["lab_runs"][-1] if data["lab_runs"] else None)
    if res:
        st.caption(f"Showing run from {res['created']}")
        st.dataframe(lab.summary_rows(res), width="stretch", hide_index=True)
        st.download_button("⬇ Report (Markdown)", lab.report_markdown(res), "prompt_lab_report.md", "text/markdown")
        st.download_button("⬇ Full results (JSON)", json.dumps(res, indent=2, ensure_ascii=False), "prompt_lab_results.json", "application/json")
        st.caption("Single run per setting: treat judge differences under ~0.3 as noise. Judges can favour length or their own style - confirm with your own expert reading.")


# ============================================================ tab: settings
def settings_tab(data):
    st.subheader("Change password")
    with st.form("chpw"):
        p1 = st.text_input("New password", type="password")
        p2 = st.text_input("Confirm new password", type="password")
        go = st.form_submit_button("Change password")
    if go:
        if p1 != p2: st.error("Passwords do not match.")
        elif len(p1) < vl.MIN_PASSWORD: st.error(f"At least {vl.MIN_PASSWORD} characters.")
        else:
            ss["vault"].change_password(p1, data)
            ss["saved_hash"] = None
            st.success("Password changed. Use the new one next time.")
    st.subheader("Backup")
    st.write(f"Encrypted data file: `{vl.VAULT_FILE}`  \nPrevious version is kept automatically as `interview_vault.bak`. Copy the `.enc` file to back it up - it stays encrypted.")
    with st.popover("Export UNENCRYPTED copy"):
        st.warning("This file is readable by anyone. Store it safely and delete it when finished.")
        st.download_button("⬇ Download plain JSON", json.dumps(data, indent=2, ensure_ascii=False), "interview_data_PLAINTEXT.json", "application/json")
    st.caption(f"Auto-lock after {IDLE_SECONDS // 60} minutes of inactivity. Five wrong passwords lock the app for 5 minutes.")


# ============================================================ main
def main():
    gate()
    data = ss["data"]
    data.setdefault("settings", {"api_key": ""}); data["settings"].setdefault("api_key", "")
    data.setdefault("lab_runs", []); data.setdefault("custom_candidate_qs", []); data.setdefault("prepared_answers", {})
    idle_watch()
    h1, h2, h3 = st.columns([6, 2, 1])
    h1.title("🛢️ Petrophysicist Interviewer Pro")
    h1.caption(jd.ROLE)
    status = h2.empty()
    if h3.button("🔒 Lock"):
        lock("Locked."); st.rerun()
    t1, t2, t3, t4, t5 = st.tabs(["Interview", "Candidate's questions", "Summary", "AI prep lab", "Settings"])
    with t1: interview_tab(data)
    with t2: candidate_tab(data)
    with t3: summary_tab(data)
    with t4: lab_tab(data)
    with t5: settings_tab(data)
    autosave(data)
    status.caption(f"💾 Auto-saved {ss.get('saved_at', '-')} (encrypted)")


main()
